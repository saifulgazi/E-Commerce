-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2021 at 10:15 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kaizen`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `title`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(6, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 1, NULL, '2021-02-08 23:51:28', '2021-02-08 23:51:28');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Bangladeshe', 1, 1, '2021-01-17 23:57:06', '2021-01-20 23:09:16'),
(2, 'Indian', 1, 1, '2021-01-18 00:05:50', '2021-01-20 23:09:39'),
(3, 'Pakistani', 1, NULL, '2021-01-23 00:06:05', '2021-01-23 00:06:05'),
(4, 'Malyasian', 1, NULL, '2021-01-23 00:06:16', '2021-01-23 00:06:16'),
(5, 'Thai', 1, NULL, '2021-01-23 00:06:36', '2021-01-23 00:06:36');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(4, 'cat01', 1, NULL, '2021-01-23 00:04:57', '2021-01-23 00:04:57'),
(5, 'cat02', 1, NULL, '2021-01-23 00:05:07', '2021-01-23 00:05:07'),
(6, 'cat03', 1, NULL, '2021-01-23 00:05:15', '2021-01-23 00:05:15'),
(7, 'cat04', 1, NULL, '2021-01-23 00:05:32', '2021-01-23 00:05:32'),
(8, 'cat05', 1, NULL, '2021-01-23 00:05:41', '2021-01-23 00:05:41'),
(9, 'cat06', 1, NULL, '2021-02-11 00:41:49', '2021-02-11 00:41:49'),
(10, 'cat07', 1, NULL, '2021-02-11 00:42:09', '2021-02-11 00:42:09');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `color`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'green', 1, NULL, '2021-01-18 01:44:19', '2021-01-18 01:44:19'),
(2, 'yellow', 1, NULL, '2021-01-18 01:44:39', '2021-01-18 01:44:39'),
(3, 'white', 1, NULL, '2021-01-20 23:10:45', '2021-01-20 23:10:45'),
(4, 'Brown', 1, NULL, '2021-01-20 23:10:59', '2021-01-20 23:10:59');

-- --------------------------------------------------------

--
-- Table structure for table `communicates`
--

CREATE TABLE `communicates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `communicates`
--

INSERT INTO `communicates` (`id`, `name`, `email`, `mobile_no`, `msg`, `created_at`, `updated_at`) VALUES
(11, 'Saiful Islam', 'saifulgazi19@gmail.com', '+8801738132047', 'test purpose', '2020-12-09 01:46:37', '2020-12-09 01:46:37'),
(12, 'Saiful Islam', 'saifulgazi19@gmail.com', '+8801738132047', 'ujgjg', '2021-02-11 00:05:27', '2021-02-11 00:05:27'),
(13, 'Saiful Islam', 'saifulgazi19@gmail.com', '+8801738132047', 'ujgjg', '2021-02-11 00:07:10', '2021-02-11 00:07:10'),
(14, 'Md. Rakib Hasan', 'saifulgazi20@gmail.com', '01630109285', 'This is testing purpose', '2021-02-11 00:11:34', '2021-02-11 00:11:34');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `address`, `email`, `mobile`, `facebook`, `twitter`, `linkedin`, `youtube`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(3, 'Dhaka bangladesh', 'saifulgazi19@gmail.com', '+8801738132047', 'http://www.facebook.com', 'https://twitter.com/', 'https://linkedin.com/', 'www.youtube.com', 1, NULL, '2021-01-22 22:23:02', '2021-02-11 00:37:13');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE `logos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logos`
--

INSERT INTO `logos` (`id`, `image`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(15, '202101230329Kaizen IT Ltd-02.png', 1, NULL, '2021-01-22 21:29:20', '2021-01-22 21:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2014_10_12_000000_create_users_table', 2),
(6, '2020_12_05_125323_create_logos_table', 3),
(7, '2020_12_05_162204_create_sliders_table', 4),
(11, '2020_12_06_083416_create_abouts_table', 5),
(14, '2020_12_06_134924_create_contacts_table', 16),
(30, '2020_12_09_053536_create_communicates_table', 20),
(35, '2020_12_09_142447_create_reaches_table', 8),
(37, '2021_01_09_085458_create_admissions_table', 9),
(38, '2021_01_16_113130_create_categories_table', 10),
(39, '2021_01_17_113854_create_brands_table', 11),
(40, '2021_01_18_062148_create_colors_table', 12),
(41, '2021_01_18_085713_create_sizes_table', 13),
(46, '2021_01_18_100820_create_products_table', 14),
(47, '2021_01_18_101719_create_product_sizes_table', 14),
(48, '2021_01_18_101850_create_product_colors_table', 14),
(49, '2021_01_18_102059_create_product_sub_images_table', 14),
(50, '2021_02_02_052622_create_shippings_table', 17),
(51, '2021_02_02_052807_create_payments_table', 17),
(52, '2021_02_02_052918_create_orders_table', 17),
(53, '2021_02_02_053214_create_order_details_table', 17);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'user_id=customer_id',
  `shipping_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `order_total` double NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0=pending and 1=approved',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `shipping_id`, `payment_id`, `order_no`, `order_total`, `status`, `created_at`, `updated_at`) VALUES
(1, 12, 2, 1, 1, 600, 1, '2021-02-02 22:28:49', '2021-02-09 00:07:19'),
(2, 12, 2, 2, 2, 400, 1, '2021-02-03 00:44:00', '2021-02-03 00:44:00'),
(3, 12, 3, 3, 3, 600, 1, '2021-02-03 03:39:08', '2021-02-09 00:07:23'),
(4, 12, 3, 4, 4, 200, 1, '2021-02-03 04:24:42', '2021-02-09 00:07:26'),
(5, 13, 4, 5, 5, 400, 1, '2021-02-03 05:50:03', '2021-02-08 23:40:19'),
(6, 1, 5, 6, 6, 1112, 0, '2021-02-09 05:32:18', '2021-02-09 05:32:18'),
(7, 12, 6, 7, 7, 500, 0, '2021-02-11 00:26:58', '2021-02-11 00:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `color_id`, `size_id`, `quantity`, `created_at`, `updated_at`) VALUES
(1, 1, 14, 4, 1, 1, '2021-02-02 22:28:49', '2021-02-02 22:28:49'),
(2, 1, 15, 3, 2, 1, '2021-02-02 22:28:49', '2021-02-02 22:28:49'),
(3, 2, 14, 4, 1, 2, '2021-02-03 00:44:00', '2021-02-03 00:44:00'),
(4, 3, 14, 4, 1, 1, '2021-02-03 03:39:08', '2021-02-03 03:39:08'),
(5, 3, 15, 3, 2, 1, '2021-02-03 03:39:08', '2021-02-03 03:39:08'),
(6, 4, 14, 4, 1, 1, '2021-02-03 04:24:42', '2021-02-03 04:24:42'),
(7, 5, 15, 3, 2, 1, '2021-02-03 05:50:03', '2021-02-03 05:50:03'),
(8, 6, 17, 2, 2, 2, '2021-02-09 05:32:18', '2021-02-09 05:32:18'),
(9, 7, 16, 3, 3, 1, '2021-02-11 00:26:58', '2021-02-11 00:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `payment_method`, `transaction_no`, `created_at`, `updated_at`) VALUES
(1, 'Hand Cash', NULL, '2021-02-02 22:28:49', '2021-02-02 22:28:49'),
(2, 'Hand Cash', NULL, '2021-02-03 00:43:59', '2021-02-03 00:43:59'),
(3, 'Hand Cash', NULL, '2021-02-03 03:39:08', '2021-02-03 03:39:08'),
(4, 'Bkash', 't52Y2575xyt12', '2021-02-03 04:24:42', '2021-02-03 04:24:42'),
(5, 'Bkash', '58528785de4', '2021-02-03 05:50:03', '2021-02-03 05:50:03'),
(6, 'Bkash', '58528785de4', '2021-02-09 05:32:18', '2021-02-09 05:32:18'),
(7, 'Bkash', '585cfrgl85de4', '2021-02-11 00:26:58', '2021-02-11 00:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `brand_id`, `name`, `slug`, `price`, `short_desc`, `long_desc`, `image`, `created_at`, `updated_at`) VALUES
(13, 4, 1, 'product01', 'product01', '100', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has', '202101230616product-01.jpg', '2021-01-23 00:16:49', '2021-01-23 00:16:49'),
(14, 5, 2, 'product02', 'product02', '200', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has', '202101230618product-08.jpg', '2021-01-23 00:18:50', '2021-01-23 00:18:50'),
(15, 7, 3, 'product03', 'product03', '400', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has', '202101230620product-06.jpg', '2021-01-23 00:20:10', '2021-01-23 00:20:10'),
(16, 8, 5, 'product05', 'product05', '500', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has', '202101230621product-12.jpg', '2021-01-23 00:21:18', '2021-01-23 00:21:18'),
(17, 6, 1, 'bangla', 'bangla', '556', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110640product-11.jpg', '2021-02-09 05:27:37', '2021-02-11 00:40:30'),
(18, 4, 1, 'product06', 'product06', '2000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110650product-03.jpg', '2021-02-11 00:50:34', '2021-02-11 00:50:34'),
(19, 7, 2, 'product07', 'product07', '3000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110652product-02.jpg', '2021-02-11 00:52:45', '2021-02-11 00:52:45'),
(20, 8, 3, 'product08', 'product08', '4000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110655product-07.jpg', '2021-02-11 00:55:09', '2021-02-11 00:55:09'),
(21, 7, 4, 'product09', 'product09', '5000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110700product-05.jpg', '2021-02-11 00:56:58', '2021-02-11 01:00:18'),
(22, 6, 5, 'product10', 'product10', '7000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110659product-04.jpg', '2021-02-11 00:59:37', '2021-02-11 00:59:37'),
(23, 9, 1, 'product11', 'product11', '5000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110702product-detail-03.jpg', '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(24, 10, 5, 'product12', 'product12', '6000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '202102110707product-16.jpg', '2021-02-11 01:04:34', '2021-02-11 01:07:10');

-- --------------------------------------------------------

--
-- Table structure for table `product_colors`
--

CREATE TABLE `product_colors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `color_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_colors`
--

INSERT INTO `product_colors` (`id`, `product_id`, `color_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, '2021-01-19 06:02:21', '2021-01-19 06:02:21'),
(2, 2, 2, '2021-01-19 21:42:55', '2021-01-19 21:42:55'),
(3, 3, 2, '2021-01-19 22:16:15', '2021-01-19 22:16:15'),
(4, 4, 2, '2021-01-19 22:31:54', '2021-01-19 22:31:54'),
(9, 5, 1, '2021-01-20 03:31:55', '2021-01-20 03:31:55'),
(10, 5, 2, '2021-01-20 03:31:55', '2021-01-20 03:31:55'),
(18, 7, 1, '2021-01-20 04:15:27', '2021-01-20 04:15:27'),
(41, 23, 1, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(42, 23, 2, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(43, 23, 3, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(44, 23, 4, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(53, 24, 1, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(54, 24, 2, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(55, 24, 3, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(56, 24, 4, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(57, 13, 1, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(58, 13, 2, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(59, 13, 3, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(60, 13, 4, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(61, 14, 1, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(62, 14, 2, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(63, 14, 3, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(64, 14, 4, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(65, 15, 1, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(66, 15, 2, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(67, 15, 3, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(68, 15, 4, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(69, 16, 1, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(70, 16, 2, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(71, 16, 3, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(72, 16, 4, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(73, 17, 1, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(74, 17, 2, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(75, 17, 3, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(76, 17, 4, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(77, 18, 1, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(78, 18, 2, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(79, 18, 3, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(80, 18, 4, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(81, 19, 1, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(82, 19, 2, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(83, 19, 3, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(84, 19, 4, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(85, 20, 1, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(86, 20, 2, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(87, 20, 3, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(88, 20, 4, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(89, 21, 1, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(90, 21, 2, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(91, 21, 3, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(92, 21, 4, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(93, 22, 1, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(94, 22, 2, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(95, 22, 3, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(96, 22, 4, '2021-02-11 01:12:38', '2021-02-11 01:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `product_sizes`
--

CREATE TABLE `product_sizes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_sizes`
--

INSERT INTO `product_sizes` (`id`, `product_id`, `size_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2021-01-19 06:02:21', '2021-01-19 06:02:21'),
(2, 2, 2, '2021-01-19 21:42:55', '2021-01-19 21:42:55'),
(3, 3, 2, '2021-01-19 22:16:15', '2021-01-19 22:16:15'),
(4, 4, 2, '2021-01-19 22:31:54', '2021-01-19 22:31:54'),
(9, 5, 1, '2021-01-20 03:31:55', '2021-01-20 03:31:55'),
(10, 5, 2, '2021-01-20 03:31:55', '2021-01-20 03:31:55'),
(18, 7, 1, '2021-01-20 04:15:27', '2021-01-20 04:15:27'),
(42, 23, 1, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(43, 23, 2, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(44, 23, 3, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(45, 23, 4, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(46, 23, 5, '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(57, 24, 1, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(58, 24, 2, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(59, 24, 3, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(60, 24, 4, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(61, 24, 5, '2021-02-11 01:07:10', '2021-02-11 01:07:10'),
(62, 13, 1, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(63, 13, 2, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(64, 13, 3, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(65, 13, 4, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(66, 13, 5, '2021-02-11 01:08:27', '2021-02-11 01:08:27'),
(67, 14, 1, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(68, 14, 2, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(69, 14, 3, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(70, 14, 4, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(71, 14, 5, '2021-02-11 01:08:52', '2021-02-11 01:08:52'),
(72, 15, 1, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(73, 15, 2, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(74, 15, 3, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(75, 15, 4, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(76, 15, 5, '2021-02-11 01:09:18', '2021-02-11 01:09:18'),
(77, 16, 1, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(78, 16, 2, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(79, 16, 3, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(80, 16, 4, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(81, 16, 5, '2021-02-11 01:09:51', '2021-02-11 01:09:51'),
(82, 17, 1, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(83, 17, 2, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(84, 17, 3, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(85, 17, 4, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(86, 17, 5, '2021-02-11 01:10:20', '2021-02-11 01:10:20'),
(87, 18, 1, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(88, 18, 2, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(89, 18, 3, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(90, 18, 4, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(91, 18, 5, '2021-02-11 01:10:46', '2021-02-11 01:10:46'),
(92, 19, 1, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(93, 19, 2, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(94, 19, 3, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(95, 19, 4, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(96, 19, 5, '2021-02-11 01:11:13', '2021-02-11 01:11:13'),
(97, 20, 1, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(98, 20, 3, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(99, 20, 4, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(100, 20, 5, '2021-02-11 01:11:54', '2021-02-11 01:11:54'),
(101, 21, 1, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(102, 21, 3, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(103, 21, 4, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(104, 21, 5, '2021-02-11 01:12:22', '2021-02-11 01:12:22'),
(105, 22, 1, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(106, 22, 2, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(107, 22, 3, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(108, 22, 4, '2021-02-11 01:12:38', '2021-02-11 01:12:38'),
(109, 22, 5, '2021-02-11 01:12:38', '2021-02-11 01:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `product_sub_images`
--

CREATE TABLE `product_sub_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sub_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_sub_images`
--

INSERT INTO `product_sub_images` (`id`, `product_id`, `sub_image`, `created_at`, `updated_at`) VALUES
(1, 1, '202101191202202012050634avatar-1.jpg', '2021-01-19 06:02:21', '2021-01-19 06:02:21'),
(2, 1, '202101191202IMG_8423.jpg', '2021-01-19 06:02:21', '2021-01-19 06:02:21'),
(3, 2, '202101200342202012050634avatar-1.jpg', '2021-01-19 21:42:55', '2021-01-19 21:42:55'),
(4, 2, '202101200342IMG_8423.jpg', '2021-01-19 21:42:55', '2021-01-19 21:42:55'),
(5, 4, '202101200431202012050634avatar-1.jpg', '2021-01-19 22:31:54', '2021-01-19 22:31:54'),
(6, 4, '202101200431IMG_8423.jpg', '2021-01-19 22:31:54', '2021-01-19 22:31:54'),
(9, 5, '2021012009221 (1).jpg', '2021-01-20 03:22:59', '2021-01-20 03:22:59'),
(10, 5, '202101200922IMG_20210107_162514.jpg', '2021-01-20 03:22:59', '2021-01-20 03:22:59'),
(22, 13, '202101230616product-detail-01.jpg', '2021-01-23 00:16:49', '2021-01-23 00:16:49'),
(23, 13, '202101230616product-detail-02.jpg', '2021-01-23 00:16:49', '2021-01-23 00:16:49'),
(24, 13, '202101230616product-detail-03.jpg', '2021-01-23 00:16:49', '2021-01-23 00:16:49'),
(25, 14, '202101230618product-13.jpg', '2021-01-23 00:18:50', '2021-01-23 00:18:50'),
(26, 14, '202101230618product-14.jpg', '2021-01-23 00:18:50', '2021-01-23 00:18:50'),
(27, 14, '202101230618product-15.jpg', '2021-01-23 00:18:50', '2021-01-23 00:18:50'),
(28, 15, '202101230620product-14.jpg', '2021-01-23 00:20:10', '2021-01-23 00:20:10'),
(29, 15, '202101230620product-15.jpg', '2021-01-23 00:20:10', '2021-01-23 00:20:10'),
(30, 15, '202101230620product-detail-03.jpg', '2021-01-23 00:20:10', '2021-01-23 00:20:10'),
(31, 16, '202101230621product-09.jpg', '2021-01-23 00:21:18', '2021-01-23 00:21:18'),
(32, 16, '202101230621product-10.jpg', '2021-01-23 00:21:18', '2021-01-23 00:21:18'),
(33, 16, '202101230621product-12.jpg', '2021-01-23 00:21:18', '2021-01-23 00:21:18'),
(34, 17, '202102091127banner-01.jpg', '2021-02-09 05:27:37', '2021-02-09 05:27:37'),
(35, 17, '202102091127banner-02.jpg', '2021-02-09 05:27:37', '2021-02-09 05:27:37'),
(36, 17, '202102091127banner-05.jpg', '2021-02-09 05:27:37', '2021-02-09 05:27:37'),
(37, 18, '202102110650item-cart-05.jpg', '2021-02-11 00:50:34', '2021-02-11 00:50:34'),
(38, 18, '202102110650product-02.jpg', '2021-02-11 00:50:34', '2021-02-11 00:50:34'),
(39, 18, '202102110650product-03.jpg', '2021-02-11 00:50:34', '2021-02-11 00:50:34'),
(40, 19, '202102110652product-01.jpg', '2021-02-11 00:52:45', '2021-02-11 00:52:45'),
(41, 19, '202102110652product-04.jpg', '2021-02-11 00:52:45', '2021-02-11 00:52:45'),
(42, 19, '202102110652product-05.jpg', '2021-02-11 00:52:45', '2021-02-11 00:52:45'),
(43, 20, '202102110655product-04.jpg', '2021-02-11 00:55:09', '2021-02-11 00:55:09'),
(44, 20, '202102110655product-05.jpg', '2021-02-11 00:55:09', '2021-02-11 00:55:09'),
(45, 20, '202102110655product-08.jpg', '2021-02-11 00:55:09', '2021-02-11 00:55:09'),
(46, 21, '202102110656product-01.jpg', '2021-02-11 00:56:58', '2021-02-11 00:56:58'),
(47, 21, '202102110656product-02.jpg', '2021-02-11 00:56:58', '2021-02-11 00:56:58'),
(48, 21, '202102110656product-04.jpg', '2021-02-11 00:56:58', '2021-02-11 00:56:58'),
(49, 22, '202102110659product-05.jpg', '2021-02-11 00:59:37', '2021-02-11 00:59:37'),
(50, 22, '202102110659product-07.jpg', '2021-02-11 00:59:37', '2021-02-11 00:59:37'),
(51, 22, '202102110659product-10.jpg', '2021-02-11 00:59:37', '2021-02-11 00:59:37'),
(52, 23, '202102110702product-detail-01.jpg', '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(53, 23, '202102110702product-detail-02.jpg', '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(54, 23, '202102110702product-min-03.jpg', '2021-02-11 01:02:53', '2021-02-11 01:02:53'),
(55, 24, '202102110704product-05.jpg', '2021-02-11 01:04:34', '2021-02-11 01:04:34'),
(56, 24, '202102110704product-07.jpg', '2021-02-11 01:04:34', '2021-02-11 01:04:34'),
(57, 24, '202102110704product-14.jpg', '2021-02-11 01:04:34', '2021-02-11 01:04:34');

-- --------------------------------------------------------

--
-- Table structure for table `reaches`
--

CREATE TABLE `reaches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `map` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reaches`
--

INSERT INTO `reaches` (`id`, `address`, `email`, `mobile`, `map`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Dhaka, Bangladesh', 'saifulgazi19@gmail.com', '+88 01630-109285', NULL, 1, NULL, '2021-01-10 03:33:58', '2021-01-10 03:33:58');

-- --------------------------------------------------------

--
-- Table structure for table `shippings`
--

CREATE TABLE `shippings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'user_id=customer_id',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shippings`
--

INSERT INTO `shippings` (`id`, `user_id`, `name`, `email`, `mobile_no`, `address`, `created_at`, `updated_at`) VALUES
(1, 12, 'Saiful Islam', 'saifulgazi19@gmail.com', '+8801738132047', 'kawran bazar dhaka', '2021-02-02 03:41:59', '2021-02-02 03:41:59'),
(2, 12, 'Saiful Islam', 'saifulgazi20@gmail.com', '+8801738132047', 'kawran bazar dhaka', '2021-02-02 22:28:37', '2021-02-02 22:28:37'),
(3, 12, 'Saiful Islam', 'saifulgazi20@gmail.com', '+8801738132047', 'kawran bazar dhaka', '2021-02-03 03:37:50', '2021-02-03 03:37:50'),
(4, 13, 'Saiful Islam', 'saifulgazi19@gmail.com', '+8801738132042', 'kawran bazar dhaka', '2021-02-03 05:49:36', '2021-02-03 05:49:36'),
(5, 1, 'Saiful Islam', 'saifulgazi19@gmail.com', '+8801738132047', 'kawran bazar dhaka', '2021-02-09 05:30:20', '2021-02-09 05:30:20'),
(6, 12, 'Saiful Islam', 'saifulgazi258@gmail.com', '+8801738132047', 'kawran bazar dhaka', '2021-02-11 00:26:23', '2021-02-11 00:26:23');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `size`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'extra large(XL)', 1, 1, '2021-01-18 03:37:44', '2021-02-11 00:45:20'),
(2, 'large(L)', 1, 1, '2021-01-18 03:37:56', '2021-02-11 00:45:41'),
(3, 'extra extra large(XXL)', 1, 1, '2021-01-20 23:11:30', '2021-02-11 00:47:22'),
(4, 'medium(M)', 1, NULL, '2021-02-11 00:47:48', '2021-02-11 00:47:48'),
(5, 'small(S)', 1, NULL, '2021-02-11 00:48:08', '2021-02-11 00:48:08');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `image`, `short_title`, `long_title`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(21, '202101230542rice04.jpg', 'Time to Start', 'Buy From Here', 1, 1, '2021-01-22 23:11:02', '2021-01-22 23:42:03'),
(22, '202101230543rice05.jpg', 'Time to Start', 'Buy From Here', 1, 1, '2021-01-22 23:11:35', '2021-01-22 23:43:44'),
(23, '202101230553rice07.jpg', 'Time to Start', 'Buy From Here', 1, 1, '2021-01-22 23:11:52', '2021-01-22 23:53:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usertype` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(91) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `usertype`, `name`, `email`, `role`, `email_verified_at`, `password`, `mobile`, `code`, `address`, `gender`, `image`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Md. Saiful Islam', 'saifulgazi19@gmail.com', 'admin', NULL, '$2y$10$piDjNuJDY3CzSc3VxZnTIe0srqfMjyxa6shiIZLQkjhH.QB6nepRy', '01630109285', NULL, 'Nawabpur Road, Dhaka', 'Male', '202101140625202012050634avatar-1.jpg', 1, NULL, NULL, '2021-01-14 00:25:35'),
(3, 'user', 'kabir', 'kabir@gmail.com', NULL, NULL, '$2y$10$ZVSSowvYo0mTv0vS14Nq5urnJJd.W8/czLf3T0h/974H5nPU5Q3T6', NULL, NULL, NULL, NULL, NULL, 1, NULL, '2020-12-05 05:09:20', '2020-12-05 05:09:20'),
(10, 'admin', 'Karim', 'karim@gmail.com', 'user', NULL, '$2y$10$aSAJYFcKP4hfe5TULTDq4ecfRkSS/2k3up0EOtFvYKJrYQP91wP6a', NULL, NULL, NULL, NULL, NULL, 1, NULL, '2021-01-31 23:19:39', '2021-01-31 23:19:39'),
(12, 'customer', 'Saiful Islam', 'saifulgazi1258@gmail.com', NULL, NULL, '$2y$10$LW7bR/rppsQBHbCK.2pHhegRZvD6XcN0VzL0bZaqU9WVGuYRn3naG', '+8801738132045', '61', 'kawran bazar dhaka', 'Male', '202102100512202012050634avatar-1.jpg', 1, NULL, '2021-02-01 05:41:58', '2021-02-09 23:21:32'),
(13, 'customer', 'gazi', 'saiifuulislam@gmail.com', NULL, NULL, '$2y$10$jJ0vhX9QbZD51Sl.zSlQ0eQeloo1H2jHbXfyqlZX/ri7g4yDbvfOq', '01630109225', '4948', NULL, NULL, NULL, 1, NULL, '2021-02-03 05:27:14', '2021-02-03 05:30:14');

-- --------------------------------------------------------

--
-- Table structure for table `visions`
--

CREATE TABLE `visions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `visions`
--

INSERT INTO `visions` (`id`, `image`, `title`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(2, '202101110423Vision.jpg', 'Mission Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem', 1, 1, '2020-12-06 00:43:07', '2021-01-10 22:23:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `communicates`
--
ALTER TABLE `communicates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logos`
--
ALTER TABLE `logos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_name_unique` (`name`);

--
-- Indexes for table `product_colors`
--
ALTER TABLE `product_colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sizes`
--
ALTER TABLE `product_sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sub_images`
--
ALTER TABLE `product_sub_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reaches`
--
ALTER TABLE `reaches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shippings`
--
ALTER TABLE `shippings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `visions`
--
ALTER TABLE `visions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `communicates`
--
ALTER TABLE `communicates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logos`
--
ALTER TABLE `logos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_colors`
--
ALTER TABLE `product_colors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `product_sizes`
--
ALTER TABLE `product_sizes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `product_sub_images`
--
ALTER TABLE `product_sub_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `reaches`
--
ALTER TABLE `reaches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shippings`
--
ALTER TABLE `shippings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `visions`
--
ALTER TABLE `visions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
